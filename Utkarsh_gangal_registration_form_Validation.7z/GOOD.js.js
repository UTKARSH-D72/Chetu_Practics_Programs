var std = [];



function Submit() {
  var table =
    "<table border=2><tr><th>Enrollment</th><th>Student Name</th><th>branch</th><th>Email</th><th>Contect</th><th>Image</th><th>Passwords</th><th>Gender</th></tr>";
  var enroll = document.getElementById("enroll").value;
  var sname = document.getElementById("name").value;
  
    var x = document.forms["myForm"]["name"].value;
    if (x == "") {
      alert("Name must be filled out");
      return false;
    }
  
  
  var branch = document.getElementById("branch").value;
  var x = document.forms["myForm"]["branch"].value;
    if (x == "") {
      document.getElementById('name').style.color="red"
      return false;
    }
  var email = document.getElementById("email").value;
  var phone = document.getElementById("phone").value;
  var image = document.getElementById("img").value;
  let corect = document.getElementById("password1").value;
  let correct =document.getElementById("password2").value;
  var c = document.forms["myForm"]["password2"].value;
  if(corect===correct)
  {
     return false;
  } 
  else
  {
     alert("undefined");
  }
  var gender;
  
  if(document.getElementById('m').checked)
  {
       gender="M"
  }
  else if(document.getElementById('m1').checked)
  {
     gender="F"
  }
  else if(document.getElementById('m2').checked)
  {
     gender="O"
  }
  else
  {
    gender="not choice"
  }
  
  std.push({
    enroll: enroll,
    sname: sname,
    branch: branch,
    email: email,
    phone: phone,
    image: image,
    password:password2,
    gender: gender,
  });
  std.forEach(function (x, y) {
    table += `<tr><th>${x.enroll}</th><th>${x.sname}</th><th>${x.branch}</th><th>${x.email}</th><th>${x.phone}</th><th>${x.image}</th><th>${x.password}</th><th>${x.gender}</th></tr>`;
  });
    document.getElementById("output").innerHTML = table;
 
}

